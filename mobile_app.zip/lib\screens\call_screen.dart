import 'dart:async';
import 'package:flutter/material.dart';
import '../services/api_service.dart';

class CallScreen extends StatefulWidget {
  final String peerId;
  final String peerName;
  final String callType; // 'audio' or 'video'
  final String? threadId;
  final bool isCaller;
  final String? incomingCallId;

  const CallScreen({
    super.key,
    required this.peerId,
    required this.peerName,
    required this.callType,
    this.threadId,
    this.isCaller = true,
    this.incomingCallId,
  });

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  String? _callId;
  String _statusText = 'Calling...';
  bool _isConnected = false;
  bool _isMuted = false;
  bool _isSpeakerOn = false;
  int _callSeconds = 0;
  Timer? _callDurationTimer;
  Timer? _signalingTimer;

  @override
  void initState() {
    super.initState();
    _callId = widget.incomingCallId;
    _initCall();
  }

  @override
  void dispose() {
    _signalingTimer?.cancel();
    _callDurationTimer?.cancel();
    _hangUp();
    super.dispose();
  }

  Future<void> _initCall() async {
    if (widget.isCaller) {
      setState(() => _statusText = 'Ringing...');
      try {
        final res = await ApiService.instance.startCall(
          peerId: widget.peerId,
          callType: widget.callType,
          threadId: widget.threadId,
        );
        if (res['ok'] == true) {
          _callId = res['call_id']?.toString();
          _startSignalingPolling();
        } else {
          setState(() => _statusText = res['error'] ?? 'User unavailable');
          Future.delayed(const Duration(seconds: 2), () {
            if (mounted) Navigator.pop(context);
          });
        }
      } catch (_) {
        setState(() => _statusText = 'Connection failed');
      }
    } else {
      setState(() => _statusText = 'Connecting...');
      if (_callId != null) {
        await ApiService.instance.respondCall(callId: _callId!, status: 'accepted');
        setState(() {
          _isConnected = true;
          _statusText = 'Connected';
        });
        _startDurationTimer();
        _startSignalingPolling();
      }
    }
  }

  void _startDurationTimer() {
    _callDurationTimer?.cancel();
    _callDurationTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _callSeconds++);
    });
  }

  void _startSignalingPolling() {
    _signalingTimer?.cancel();
    _signalingTimer = Timer.periodic(const Duration(seconds: 2), (_) async {
      if (_callId == null) return;
      try {
        final data = await ApiService.instance.pollCall(_callId!);
        final call = data['call'];
        if (call == null) return;

        final status = call['status']?.toString();
        if (status == 'declined' || status == 'ended' || status == 'busy') {
          setState(() => _statusText = 'Call $status');
          _signalingTimer?.cancel();
          Future.delayed(const Duration(seconds: 1), () {
            if (mounted) Navigator.pop(context);
          });
          return;
        }

        if (widget.isCaller && status == 'accepted' && !_isConnected) {
          setState(() {
            _isConnected = true;
            _statusText = 'Connected';
          });
          _startDurationTimer();
        }
      } catch (_) {}
    });
  }

  Future<void> _hangUp() async {
    _signalingTimer?.cancel();
    if (_callId != null) {
      try {
        await ApiService.instance.respondCall(callId: _callId!, status: 'ended');
      } catch (_) {}
    }
  }

  String _formatCallTime(int secs) {
    final m = (secs ~/ 60).toString().padLeft(2, '0');
    final s = (secs % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final isVideo = widget.callType == 'video';

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: SafeArea(
        child: Column(
          children: [
            const Spacer(),
            Center(
              child: Column(
                children: [
                  Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [
                          const Color(0xFF10B981),
                          const Color(0xFF059669).withOpacity(0.8),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF10B981).withOpacity(0.3),
                          blurRadius: 30,
                          spreadRadius: 8,
                        ),
                      ],
                    ),
                    child: Center(
                      child: Text(
                        widget.peerName.isNotEmpty ? widget.peerName[0].toUpperCase() : 'U',
                        style: const TextStyle(fontSize: 52, color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  const SizedBox(height: 28),
                  Text(
                    widget.peerName,
                    style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.white10,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      _isConnected ? _formatCallTime(_callSeconds) : '${widget.callType.toUpperCase()} • $_statusText',
                      style: TextStyle(
                        fontSize: 14,
                        color: _isConnected ? const Color(0xFF10B981) : Colors.white70,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const Spacer(),
            Padding(
              padding: const EdgeInsets.only(bottom: 40),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _RoundButton(
                    icon: _isMuted ? Icons.mic_off : Icons.mic,
                    color: _isMuted ? Colors.red : Colors.white12,
                    iconColor: Colors.white,
                    onTap: () => setState(() => _isMuted = !_isMuted),
                  ),
                  _RoundButton(
                    icon: _isSpeakerOn ? Icons.volume_up : Icons.volume_down,
                    color: _isSpeakerOn ? const Color(0xFF10B981) : Colors.white12,
                    iconColor: Colors.white,
                    onTap: () => setState(() => _isSpeakerOn = !_isSpeakerOn),
                  ),
                  _RoundButton(
                    icon: Icons.call_end,
                    color: Colors.redAccent,
                    iconColor: Colors.white,
                    size: 68,
                    onTap: () {
                      _hangUp();
                      Navigator.pop(context);
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RoundButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final Color iconColor;
  final double size;
  final VoidCallback onTap;

  const _RoundButton({
    required this.icon,
    required this.color,
    required this.iconColor,
    this.size = 56,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      customBorder: const CircleBorder(),
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(shape: BoxShape.circle, color: color),
        child: Icon(icon, color: iconColor, size: size * 0.48),
      ),
    );
  }
}
