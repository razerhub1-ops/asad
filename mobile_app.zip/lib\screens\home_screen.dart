import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../config/api_config.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import 'chat_screen.dart';
import 'call_screen.dart';
import 'login_screen.dart';
import 'support_screen.dart';
import 'user_search_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  int _unreadDmCount = 0;
  int _pendingFrCount = 0;
  int _unreadSupportCount = 0;
  Timer? _statusTimer;
  String? _handledCallId;

  final GlobalKey<_ChatsTabState> _chatsKey = GlobalKey();
  final GlobalKey<_FriendsTabState> _friendsKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    _checkStatusAndIncomingCalls();
    _statusTimer = Timer.periodic(const Duration(seconds: 4), (_) => _checkStatusAndIncomingCalls());
  }

  @override
  void dispose() {
    _statusTimer?.cancel();
    super.dispose();
  }

  Future<void> _checkStatusAndIncomingCalls() async {
    try {
      final res = await ApiService.instance.getInit();
      if (!mounted) return;

      setState(() {
        _unreadDmCount = res['unread_dm'] ?? 0;
        _pendingFrCount = res['pending_fr'] ?? 0;
        _unreadSupportCount = res['unread_support'] ?? 0;
      });

      final IncomingCallModel? incoming = res['incoming_call'];
      if (incoming != null && incoming.callId != _handledCallId) {
        _handledCallId = incoming.callId;
        _showIncomingCallDialog(incoming);
      }
    } catch (_) {}
  }

  void _showIncomingCallDialog(IncomingCallModel call) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1E293B),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircleAvatar(
              radius: 36,
              backgroundColor: const Color(0xFF10B981).withOpacity(0.2),
              child: Icon(
                call.callType == 'video' ? Icons.videocam : Icons.call,
                size: 38,
                color: const Color(0xFF10B981),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              call.callerName,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 4),
            Text(
              'Incoming ${call.callType.toUpperCase()} Call...',
              style: const TextStyle(fontSize: 14, color: Color(0xFF10B981)),
            ),
          ],
        ),
        actionsAlignment: MainAxisAlignment.spaceEvenly,
        actions: [
          IconButton(
            iconSize: 52,
            icon: const Icon(Icons.call_end, color: Colors.red),
            onPressed: () async {
              Navigator.pop(ctx);
              await ApiService.instance.respondCall(callId: call.callId, status: 'declined');
            },
          ),
          IconButton(
            iconSize: 52,
            icon: const Icon(Icons.call, color: Color(0xFF10B981)),
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => CallScreen(
                    peerId: call.callerId,
                    peerName: call.callerName,
                    callType: call.callType,
                    threadId: call.threadId,
                    isCaller: false,
                    incomingCallId: call.callId,
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = ApiService.instance.currentUser;

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E293B),
        elevation: 0,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: const Color(0xFF10B981).withOpacity(0.2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.chat_bubble_rounded, color: Color(0xFF10B981), size: 20),
            ),
            const SizedBox(width: 10),
            Text(
              _getTitleForIndex(_currentIndex),
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 19, color: Colors.white),
            ),
          ],
        ),
        actions: [
          if (_currentIndex == 0 || _currentIndex == 1)
            IconButton(
              icon: const Icon(Icons.person_search, color: Color(0xFF10B981)),
              tooltip: 'Find Friends',
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const UserSearchScreen()),
                );
              },
            ),
        ],
      ),
      body: IndexedStack(
        index: _currentIndex,
        children: [
          ChatsTab(key: _chatsKey),
          FriendsTab(key: _friendsKey),
          const SupportScreen(),
          _buildSettingsTab(user),
        ],
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: Color(0xFF1E293B),
          border: Border(top: BorderSide(color: Colors.white10, width: 0.5)),
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          backgroundColor: const Color(0xFF1E293B),
          selectedItemColor: const Color(0xFF10B981),
          unselectedItemColor: Colors.white54,
          type: BottomNavigationBarType.fixed,
          onTap: (i) => setState(() => _currentIndex = i),
          items: [
            BottomNavigationBarItem(
              icon: _buildBadgeIcon(Icons.chat_bubble, _unreadDmCount),
              label: 'Chats',
            ),
            BottomNavigationBarItem(
              icon: _buildBadgeIcon(Icons.people, _pendingFrCount),
              label: 'Friends',
            ),
            BottomNavigationBarItem(
              icon: _buildBadgeIcon(Icons.support_agent, _unreadSupportCount),
              label: 'Support',
            ),
            const BottomNavigationBarItem(
              icon: Icon(Icons.settings),
              label: 'Settings',
            ),
          ],
        ),
      ),
    );
  }

  String _getTitleForIndex(int idx) {
    switch (idx) {
      case 0:
        return 'Conversations';
      case 1:
        return 'Friends & Requests';
      case 2:
        return 'Customer Support';
      case 3:
        return 'Settings';
      default:
        return 'Chat';
    }
  }

  Widget _buildBadgeIcon(IconData icon, int count) {
    if (count <= 0) return Icon(icon);
    return Badge(
      backgroundColor: const Color(0xFF10B981),
      label: Text(
        count.toString(),
        style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
      ),
      child: Icon(icon),
    );
  }

  Widget _buildSettingsTab(UserModel? user) {
    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      children: [
        Center(
          child: Column(
            children: [
              CircleAvatar(
                radius: 46,
                backgroundColor: const Color(0xFF10B981).withOpacity(0.2),
                child: Text(
                  user?.name.isNotEmpty == true ? user!.name[0].toUpperCase() : 'U',
                  style: const TextStyle(fontSize: 40, color: Color(0xFF10B981), fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 14),
              Text(
                user?.name ?? 'User',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              const SizedBox(height: 4),
              Text(
                '@${user?.username ?? ''} • ${user?.email ?? ''}',
                style: const TextStyle(fontSize: 13, color: Colors.white60),
              ),
            ],
          ),
        ),
        const SizedBox(height: 32),
        _buildSettingsCard(
          title: 'Server Configuration',
          subtitle: ApiConfig.baseUrl,
          icon: Icons.cloud_outlined,
          onTap: () {
            final urlCtrl = TextEditingController(text: ApiConfig.baseUrl);
            showDialog(
              context: context,
              builder: (ctx) => AlertDialog(
                title: const Text('Change Backend URL'),
                content: TextField(
                  controller: urlCtrl,
                  decoration: const InputDecoration(border: OutlineInputBorder()),
                ),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
                  ElevatedButton(
                    onPressed: () async {
                      await ApiConfig.setBaseUrl(urlCtrl.text);
                      if (ctx.mounted) Navigator.pop(ctx);
                      setState(() {});
                    },
                    child: const Text('Save'),
                  ),
                ],
              ),
            );
          },
        ),
        const SizedBox(height: 14),
        _buildSettingsCard(
          title: 'Account Role',
          subtitle: user?.role.toUpperCase() ?? 'USER',
          icon: Icons.shield_outlined,
        ),
        const SizedBox(height: 28),
        SizedBox(
          height: 50,
          child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red.withOpacity(0.15),
              foregroundColor: Colors.redAccent,
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
                side: BorderSide(color: Colors.red.withOpacity(0.3)),
              ),
            ),
            icon: const Icon(Icons.logout),
            label: const Text('Sign Out', style: TextStyle(fontWeight: FontWeight.bold)),
            onPressed: () async {
              await ApiService.instance.logout();
              if (mounted) {
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                  (_) => false,
                );
              }
            },
          ),
        ),
      ],
    );
  }

  Widget _buildSettingsCard({
    required String title,
    required String subtitle,
    required IconData icon,
    VoidCallback? onTap,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(14),
      ),
      child: ListTile(
        leading: Icon(icon, color: const Color(0xFF10B981)),
        title: Text(title, style: const TextStyle(color: Colors.white, fontSize: 15)),
        subtitle: Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 13), overflow: TextOverflow.ellipsis),
        trailing: onTap != null ? const Icon(Icons.chevron_right, color: Colors.white38) : null,
        onTap: onTap,
      ),
    );
  }
}

// ── Chats Tab ────────────────────────────────────────────────────────────────
class ChatsTab extends StatefulWidget {
  const ChatsTab({super.key});

  @override
  State<ChatsTab> createState() => _ChatsTabState();
}

class _ChatsTabState extends State<ChatsTab> {
  List<DmThreadModel> _threads = [];
  bool _isLoading = true;
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _loadThreads();
    _refreshTimer = Timer.periodic(const Duration(seconds: 4), (_) => _loadThreads());
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadThreads() async {
    try {
      final list = await ApiService.instance.getDmThreads();
      if (mounted) {
        setState(() {
          _threads = list;
          _isLoading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator(color: Color(0xFF10B981)));
    }
    if (_threads.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.forum_outlined, size: 64, color: Colors.white.withOpacity(0.2)),
            const SizedBox(height: 16),
            const Text('No conversations yet', style: TextStyle(color: Colors.white70, fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('Tap the button below to find and add friends.', style: TextStyle(color: Colors.white38, fontSize: 13)),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF10B981),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              ),
              icon: const Icon(Icons.person_add, color: Colors.white),
              label: const Text('Find Friends', style: TextStyle(color: Colors.white)),
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const UserSearchScreen()),
                );
              },
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      color: const Color(0xFF10B981),
      onRefresh: _loadThreads,
      child: ListView.separated(
        itemCount: _threads.length,
        separatorBuilder: (_, __) => const Divider(color: Colors.white10, height: 1),
        itemBuilder: (ctx, i) {
          final t = _threads[i];
          return ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            leading: Stack(
              children: [
                CircleAvatar(
                  radius: 24,
                  backgroundColor: const Color(0xFF10B981).withOpacity(0.2),
                  child: Text(
                    t.peerName.isNotEmpty ? t.peerName[0].toUpperCase() : 'U',
                    style: const TextStyle(color: Color(0xFF10B981), fontWeight: FontWeight.bold, fontSize: 18),
                  ),
                ),
                if (t.isOnline)
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color: const Color(0xFF10B981),
                        shape: BoxShape.circle,
                        border: Border.all(color: const Color(0xFF0F172A), width: 2),
                      ),
                    ),
                  ),
              ],
            ),
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    t.peerName,
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 16),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Text(
                  _formatTime(t.updatedAt),
                  style: const TextStyle(color: Colors.white38, fontSize: 11),
                ),
              ],
            ),
            subtitle: Row(
              children: [
                Expanded(
                  child: Text(
                    t.lastImage != null && t.lastImage!.isNotEmpty
                        ? '📷 [Photo]'
                        : (t.lastBody?.isNotEmpty == true ? t.lastBody! : 'Start chatting...'),
                    style: TextStyle(
                      color: t.unread > 0 ? Colors.white : Colors.white54,
                      fontSize: 13,
                      fontWeight: t.unread > 0 ? FontWeight.bold : FontWeight.normal,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                if (t.unread > 0)
                  Container(
                    margin: const EdgeInsets.only(left: 6),
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: const Color(0xFF10B981),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      t.unread.toString(),
                      style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
                    ),
                  ),
              ],
            ),
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => ChatScreen(
                    threadId: t.id,
                    peerId: t.peerId,
                    peerName: t.peerName,
                    peerUsername: t.peerUsername,
                    initialIsOnline: t.isOnline,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  String _formatTime(String raw) {
    try {
      final dt = DateTime.parse(raw);
      return DateFormat('hh:mm a').format(dt.toLocal());
    } catch (_) {
      return '';
    }
  }
}

// ── Friends & Requests Tab ────────────────────────────────────────────────────
class FriendsTab extends StatefulWidget {
  const FriendsTab({super.key});

  @override
  State<FriendsTab> createState() => _FriendsTabState();
}

class _FriendsTabState extends State<FriendsTab> {
  List<FriendRequestModel> _requests = [];
  List<FriendModel> _friends = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    try {
      final reqs = await ApiService.instance.getIncomingFriendRequests();
      final frs = await ApiService.instance.getFriends();
      if (mounted) {
        setState(() {
          _requests = reqs;
          _friends = frs;
          _isLoading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _respond(FriendRequestModel req, bool accept) async {
    await ApiService.instance.respondFriendRequest(req.id, accept);
    _loadData();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator(color: Color(0xFF10B981)));
    }

    return RefreshIndicator(
      color: const Color(0xFF10B981),
      onRefresh: _loadData,
      child: ListView(
        padding: const EdgeInsets.symmetric(vertical: 12),
        children: [
          if (_requests.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text(
                'Incoming Requests (${_requests.length})',
                style: const TextStyle(color: Color(0xFF10B981), fontWeight: FontWeight.bold, fontSize: 14),
              ),
            ),
            ..._requests.map((r) => Container(
                  margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1E293B),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ListTile(
                    title: Text(r.fromName, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                    subtitle: Text(r.fromEmail, style: const TextStyle(color: Colors.white54, fontSize: 12)),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.check_circle, color: Color(0xFF10B981)),
                          onPressed: () => _respond(r, true),
                        ),
                        IconButton(
                          icon: const Icon(Icons.cancel, color: Colors.redAccent),
                          onPressed: () => _respond(r, false),
                        ),
                      ],
                    ),
                  ),
                )),
            const Divider(color: Colors.white10, height: 28),
          ],
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(
              'My Friends (${_friends.length})',
              style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold, fontSize: 14),
            ),
          ),
          if (_friends.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 20),
              child: Center(
                child: Text('No friends added yet. Use the search icon to add friends!',
                    style: TextStyle(color: Colors.white38, fontSize: 13), textAlign: TextAlign.center),
              ),
            )
          else
            ..._friends.map((f) => ListTile(
                  leading: Stack(
                    children: [
                      CircleAvatar(
                        backgroundColor: const Color(0xFF10B981).withOpacity(0.2),
                        child: Text(f.friendName.isNotEmpty ? f.friendName[0].toUpperCase() : 'F',
                            style: const TextStyle(color: Color(0xFF10B981))),
                      ),
                      if (f.isOnline)
                        Positioned(
                          right: 0,
                          bottom: 0,
                          child: Container(
                            width: 10,
                            height: 10,
                            decoration: const BoxDecoration(color: Color(0xFF10B981), shape: BoxShape.circle),
                          ),
                        ),
                    ],
                  ),
                  title: Text(f.friendName, style: const TextStyle(color: Colors.white)),
                  subtitle: Text(f.isOnline ? 'Online' : 'Offline',
                      style: TextStyle(color: f.isOnline ? const Color(0xFF10B981) : Colors.white38, fontSize: 12)),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.call, color: Color(0xFF10B981)),
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => CallScreen(
                                peerId: f.friendId,
                                peerName: f.friendName,
                                callType: 'audio',
                                threadId: f.threadId,
                                isCaller: true,
                              ),
                            ),
                          );
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.chat, color: Color(0xFF10B981)),
                        onPressed: () async {
                          final threadId = f.threadId ?? await ApiService.instance.openDm(f.friendId);
                          if (threadId != null && mounted) {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => ChatScreen(
                                  threadId: threadId,
                                  peerId: f.friendId,
                                  peerName: f.friendName,
                                  peerUsername: f.friendUsername,
                                  initialIsOnline: f.isOnline,
                                ),
                              ),
                            );
                          }
                        },
                      ),
                    ],
                  ),
                )),
        ],
      ),
    );
  }
}
