import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../config/api_config.dart';
import '../models/models.dart';

class ApiService {
  static final ApiService instance = ApiService._internal();
  ApiService._internal();

  String? _token;
  UserModel? _currentUser;

  String? get token => _token;
  UserModel? get currentUser => _currentUser;
  bool get isAuthenticated => _token != null && _currentUser != null;

  Future<void> initAuth() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('auth_token');
    final userJson = prefs.getString('current_user');
    if (userJson != null) {
      try {
        _currentUser = UserModel.fromJson(jsonDecode(userJson));
      } catch (_) {}
    }
  }

  Future<void> _saveAuth(String token, UserModel user) async {
    _token = token;
    _currentUser = user;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
    await prefs.setString('current_user', jsonEncode(user.toJson()));
  }

  Future<void> clearAuth() async {
    _token = null;
    _currentUser = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    await prefs.remove('current_user');
  }

  Map<String, String> _headers({bool isJson = true}) {
    final h = <String, String>{};
    if (isJson) {
      h['Content-Type'] = 'application/json';
    }
    if (_token != null && _token!.isNotEmpty) {
      h['Authorization'] = 'Bearer $_token';
    }
    return h;
  }

  // ── Auth ───────────────────────────────────────────────────────────────────
  Future<Map<String, dynamic>> login(String identifier, String password) async {
    final resp = await http.post(
      ApiConfig.apiUrl,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'action': 'mobile_login',
        'identifier': identifier.trim(),
        'password': password,
      }),
    );

    final data = jsonDecode(resp.body);
    if (resp.statusCode == 200 && data['ok'] == true) {
      final token = data['token'] as String;
      final user = UserModel.fromJson(data['actor']);
      await _saveAuth(token, user);
      return {'success': true, 'user': user};
    } else {
      return {'success': false, 'error': data['error'] ?? 'Login failed'};
    }
  }

  Future<Map<String, dynamic>> register({
    required String name,
    required String username,
    required String email,
    required String password,
  }) async {
    final resp = await http.post(
      ApiConfig.apiUrl,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'action': 'mobile_register',
        'name': name.trim(),
        'username': username.trim().toLowerCase(),
        'email': email.trim().toLowerCase(),
        'password': password,
      }),
    );

    final data = jsonDecode(resp.body);
    if (resp.statusCode == 200 && data['ok'] == true) {
      final token = data['token'] as String;
      final user = UserModel.fromJson(data['actor']);
      await _saveAuth(token, user);
      return {'success': true, 'user': user};
    } else {
      return {'success': false, 'error': data['error'] ?? 'Registration failed'};
    }
  }

  Future<void> logout() async {
    try {
      if (_token != null) {
        await http.post(
          ApiConfig.apiUrl,
          headers: _headers(),
          body: jsonEncode({'action': 'mobile_logout'}),
        );
      }
    } catch (_) {}
    await clearAuth();
  }

  // ── Init / Status ─────────────────────────────────────────────────────────
  Future<Map<String, dynamic>> getInit() async {
    final url = ApiConfig.apiUrl.replace(queryParameters: {'action': 'init'});
    final resp = await http.get(url, headers: _headers());
    if (resp.statusCode == 200) {
      final data = jsonDecode(resp.body);
      IncomingCallModel? incoming;
      if (data['incoming_call'] != null) {
        incoming = IncomingCallModel.fromJson(data['incoming_call']);
      }
      return {
        'pending_fr': data['pending_fr_count'] ?? 0,
        'unread_dm': data['unread_dm_count'] ?? 0,
        'unread_support': data['unread_support_count'] ?? 0,
        'incoming_call': incoming,
      };
    }
    return {};
  }

  // ── DM Threads ─────────────────────────────────────────────────────────────
  Future<List<DmThreadModel>> getDmThreads() async {
    final url = ApiConfig.apiUrl.replace(queryParameters: {'action': 'dm_threads'});
    final resp = await http.get(url, headers: _headers());
    if (resp.statusCode == 200) {
      final data = jsonDecode(resp.body);
      final list = (data['threads'] as List?) ?? [];
      return list.map((e) => DmThreadModel.fromJson(e)).toList();
    }
    return [];
  }

  Future<Map<String, dynamic>> getDmMessages(String threadId, {String? sinceId}) async {
    final params = {'action': 'dm_history', 'thread_id': threadId};
    if (sinceId != null) params['since_id'] = sinceId;
    final url = ApiConfig.apiUrl.replace(queryParameters: params);

    final resp = await http.get(url, headers: _headers());
    if (resp.statusCode == 200) {
      final data = jsonDecode(resp.body);
      final rawMsgs = (data['messages'] as List?) ?? [];
      final msgs = rawMsgs.map((e) => MessageModel.fromJson(e, _currentUser?.id ?? '')).toList();
      UserModel? peer;
      if (data['peer'] != null) {
        peer = UserModel.fromJson(data['peer']);
      }
      return {'messages': msgs, 'peer': peer};
    }
    return {'messages': <MessageModel>[], 'peer': null};
  }

  Future<bool> sendDmMessage(String threadId, String body, {String? imageUrl}) async {
    final uuid = _generateUuid();
    final resp = await http.post(
      ApiConfig.apiUrl,
      headers: _headers(),
      body: jsonEncode({
        'action': 'dm_send',
        'thread_id': threadId,
        'body': body,
        'image_url': imageUrl,
        'key': uuid,
      }),
    );
    if (resp.statusCode == 200) {
      final data = jsonDecode(resp.body);
      return data['ok'] == true;
    }
    return false;
  }

  Future<bool> deleteDmThread(String threadId) async {
    final resp = await http.post(
      ApiConfig.apiUrl,
      headers: _headers(),
      body: jsonEncode({
        'action': 'delete_dm_thread',
        'thread_id': threadId,
      }),
    );
    return resp.statusCode == 200;
  }

  // ── Support Chat ──────────────────────────────────────────────────────────
  Future<List<MessageModel>> getSupportMessages({String? afterId}) async {
    final params = {'action': 'messages'};
    if (afterId != null) params['after'] = afterId;
    final url = ApiConfig.apiUrl.replace(queryParameters: params);

    final resp = await http.get(url, headers: _headers());
    if (resp.statusCode == 200) {
      final data = jsonDecode(resp.body);
      final rawMsgs = (data['messages'] as List?) ?? [];
      return rawMsgs.map((e) => MessageModel.fromJson(e, _currentUser?.id ?? '')).toList();
    }
    return [];
  }

  Future<bool> sendSupportMessage(String body, {String? imageUrl}) async {
    final uuid = _generateUuid();
    final resp = await http.post(
      ApiConfig.apiUrl,
      headers: _headers(),
      body: jsonEncode({
        'action': 'send',
        'body': body,
        'image_url': imageUrl,
        'key': uuid,
      }),
    );
    return resp.statusCode == 200;
  }

  // ── Friends & Users ───────────────────────────────────────────────────────
  Future<List<FriendModel>> getFriends() async {
    final url = ApiConfig.apiUrl.replace(queryParameters: {'action': 'friends'});
    final resp = await http.get(url, headers: _headers());
    if (resp.statusCode == 200) {
      final data = jsonDecode(resp.body);
      final list = (data['friends'] as List?) ?? [];
      return list.map((e) => FriendModel.fromJson(e)).toList();
    }
    return [];
  }

  Future<List<FriendRequestModel>> getIncomingFriendRequests() async {
    final url = ApiConfig.apiUrl.replace(queryParameters: {'action': 'friend_requests'});
    final resp = await http.get(url, headers: _headers());
    if (resp.statusCode == 200) {
      final data = jsonDecode(resp.body);
      final list = (data['requests'] as List?) ?? [];
      return list.map((e) => FriendRequestModel.fromJson(e)).toList();
    }
    return [];
  }

  Future<List<UserModel>> searchUsers(String query) async {
    final url = ApiConfig.apiUrl.replace(queryParameters: {'action': 'users', 'query': query});
    final resp = await http.get(url, headers: _headers());
    if (resp.statusCode == 200) {
      final data = jsonDecode(resp.body);
      final list = (data['users'] as List?) ?? [];
      return list.map((e) => UserModel.fromJson(e)).toList();
    }
    return [];
  }

  Future<Map<String, dynamic>> sendFriendRequest(String toUserId) async {
    final resp = await http.post(
      ApiConfig.apiUrl,
      headers: _headers(),
      body: jsonEncode({
        'action': 'friend_request',
        'to_user_id': toUserId,
      }),
    );
    final data = jsonDecode(resp.body);
    return {'ok': data['ok'] == true, 'message': data['message'] ?? data['error']};
  }

  Future<bool> respondFriendRequest(String requestId, bool accept) async {
    final resp = await http.post(
      ApiConfig.apiUrl,
      headers: _headers(),
      body: jsonEncode({
        'action': 'friend_respond',
        'request_id': requestId,
        'accept': accept,
      }),
    );
    final data = jsonDecode(resp.body);
    return data['ok'] == true;
  }

  Future<String?> openDm(String peerId) async {
    final resp = await http.post(
      ApiConfig.apiUrl,
      headers: _headers(),
      body: jsonEncode({
        'action': 'open_dm',
        'peer_id': peerId,
      }),
    );
    final data = jsonDecode(resp.body);
    if (data['ok'] == true) {
      return data['thread_id']?.toString();
    }
    return null;
  }

  // ── Image Upload ──────────────────────────────────────────────────────────
  Future<String?> uploadImage(File file) async {
    final request = http.MultipartRequest('POST', ApiConfig.apiUrl);
    if (_token != null) {
      request.headers['Authorization'] = 'Bearer $_token';
    }
    request.fields['action'] = 'upload';
    request.files.add(await http.MultipartFile.fromPath('image', file.path));

    final streamedResponse = await request.send();
    final response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['ok'] == true) {
        return data['url']?.toString();
      }
    }
    return null;
  }

  // ── Calling Signaling ─────────────────────────────────────────────────────
  Future<Map<String, dynamic>> startCall({
    required String peerId,
    required String callType,
    String? threadId,
    String? offerSdp,
  }) async {
    final resp = await http.post(
      ApiConfig.apiUrl,
      headers: _headers(),
      body: jsonEncode({
        'action': 'call_start',
        'peer_id': peerId,
        'call_type': callType,
        'thread_id': threadId,
        'offer_sdp': offerSdp,
      }),
    );
    return jsonDecode(resp.body);
  }

  Future<bool> respondCall({
    required String callId,
    required String status,
    String? answerSdp,
  }) async {
    final resp = await http.post(
      ApiConfig.apiUrl,
      headers: _headers(),
      body: jsonEncode({
        'action': 'call_respond',
        'call_id': callId,
        'status': status,
        'answer_sdp': answerSdp,
      }),
    );
    final data = jsonDecode(resp.body);
    return data['ok'] == true;
  }

  Future<Map<String, dynamic>> pollCall(String callId, {String? lastCandidateId}) async {
    final params = {'action': 'call_poll', 'call_id': callId};
    if (lastCandidateId != null) params['last_candidate_id'] = lastCandidateId;
    final url = ApiConfig.apiUrl.replace(queryParameters: params);

    final resp = await http.get(url, headers: _headers());
    if (resp.statusCode == 200) {
      return jsonDecode(resp.body);
    }
    return {};
  }

  Future<bool> sendCandidate(String callId, String candidateJson) async {
    final resp = await http.post(
      ApiConfig.apiUrl,
      headers: _headers(),
      body: jsonEncode({
        'action': 'call_candidate',
        'call_id': callId,
        'candidate': candidateJson,
      }),
    );
    final data = jsonDecode(resp.body);
    return data['ok'] == true;
  }

  String _generateUuid() {
    final rnd = DateTime.now().microsecondsSinceEpoch.toString();
    final padded = rnd.padLeft(32, '0');
    return '${padded.substring(0,8)}-${padded.substring(8,12)}-4${padded.substring(13,16)}-a${padded.substring(17,20)}-${padded.substring(20,32)}';
  }
}
