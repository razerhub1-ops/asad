import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import 'chat_screen.dart';

class UserSearchScreen extends StatefulWidget {
  const UserSearchScreen({super.key});

  @override
  State<UserSearchScreen> createState() => _UserSearchScreenState();
}

class _UserSearchScreenState extends State<UserSearchScreen> {
  final _searchController = TextEditingController();
  List<UserModel> _results = [];
  bool _isLoading = false;
  String? _message;

  Future<void> _handleSearch(String query) async {
    final clean = query.trim();
    if (clean.length < 2) {
      setState(() {
        _results = [];
        _message = 'Type at least 2 characters to search.';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _message = null;
    });

    try {
      final list = await ApiService.instance.searchUsers(clean);
      setState(() {
        _results = list;
        if (list.isEmpty) {
          _message = 'No users found matching "$clean".';
        }
      });
    } catch (_) {
      setState(() => _message = 'Search failed. Check your connection.');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _sendRequest(UserModel user) async {
    try {
      final res = await ApiService.instance.sendFriendRequest(user.id);
      if (res['ok'] == true) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(res['message'] ?? 'Friend request sent!')),
        );
        _handleSearch(_searchController.text);
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(res['message'] ?? 'Could not send request.')),
        );
      }
    } catch (_) {}
  }

  Future<void> _openChat(UserModel user) async {
    try {
      final threadId = await ApiService.instance.openDm(user.id);
      if (threadId != null && mounted) {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => ChatScreen(
              threadId: threadId,
              peerId: user.id,
              peerName: user.name,
              peerUsername: user.username,
              initialIsOnline: user.isOnline,
            ),
          ),
        );
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E293B),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        title: TextField(
          controller: _searchController,
          autofocus: true,
          style: const TextStyle(color: Colors.white),
          textInputAction: TextInputAction.search,
          onSubmitted: _handleSearch,
          decoration: const InputDecoration(
            hintText: 'Search by username or name...',
            hintStyle: TextStyle(color: Colors.white38),
            border: InputBorder.none,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: Color(0xFF10B981)),
            onPressed: () => _handleSearch(_searchController.text),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFF10B981)))
          : _message != null
              ? Center(
                  child: Text(
                    _message!,
                    style: const TextStyle(color: Colors.white54, fontSize: 14),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  itemCount: _results.length,
                  separatorBuilder: (_, __) => const Divider(color: Colors.white10, height: 1),
                  itemBuilder: (ctx, i) {
                    final u = _results[i];
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: const Color(0xFF10B981).withOpacity(0.2),
                        child: Text(
                          u.name.isNotEmpty ? u.name[0].toUpperCase() : 'U',
                          style: const TextStyle(color: Color(0xFF10B981), fontWeight: FontWeight.bold),
                        ),
                      ),
                      title: Text(
                        u.name,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                      ),
                      subtitle: Text(
                        '@${u.username}',
                        style: const TextStyle(color: Colors.white54, fontSize: 13),
                      ),
                      trailing: _buildActionBadge(u),
                    );
                  },
                ),
    );
  }

  Widget _buildActionBadge(UserModel u) {
    if (u.frStatus == 'accepted') {
      return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF10B981),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        ),
        onPressed: () => _openChat(u),
        child: const Text('Message', style: TextStyle(color: Colors.white, fontSize: 13)),
      );
    } else if (u.frStatus == 'pending_sent') {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.white10,
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Text('Pending', style: TextStyle(color: Colors.white60, fontSize: 12)),
      );
    } else {
      return OutlinedButton.icon(
        style: OutlinedButton.styleFrom(
          foregroundColor: const Color(0xFF10B981),
          side: const BorderSide(color: Color(0xFF10B981)),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        ),
        icon: const Icon(Icons.person_add, size: 16),
        label: const Text('Add', style: TextStyle(fontSize: 13)),
        onPressed: () => _sendRequest(u),
      );
    }
  }
}
