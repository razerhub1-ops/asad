import 'package:shared_preferences/shared_preferences.dart';

class ApiConfig {
  static const String _defaultBaseUrl = 'https://razerhubdigitalagency.com/chat';
  static const String _keyBaseUrl = 'custom_base_url';

  static String _currentBaseUrl = _defaultBaseUrl;

  static String get baseUrl => _currentBaseUrl;

  static Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _currentBaseUrl = prefs.getString(_keyBaseUrl) ?? _defaultBaseUrl;
  }

  static Future<void> setBaseUrl(String url) async {
    String clean = url.trim();
    if (clean.endsWith('/')) {
      clean = clean.substring(0, clean.length - 1);
    }
    _currentBaseUrl = clean;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyBaseUrl, clean);
  }

  static Uri get apiUrl => Uri.parse('$_currentBaseUrl/api.php');

  static String resolveUrl(String relativeOrAbsolute) {
    if (relativeOrAbsolute.startsWith('http://') || relativeOrAbsolute.startsWith('https://')) {
      return relativeOrAbsolute;
    }
    String cleanRel = relativeOrAbsolute.startsWith('/') ? relativeOrAbsolute.substring(1) : relativeOrAbsolute;
    return '$_currentBaseUrl/$cleanRel';
  }
}
