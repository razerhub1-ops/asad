class UserModel {
  final String id;
  final String name;
  final String username;
  final String email;
  final String role;
  final bool isOnline;
  final String? lastSeen;
  final String? frStatus;
  final String? reqId;

  UserModel({
    required this.id,
    required this.name,
    required this.username,
    required this.email,
    required this.role,
    this.isOnline = false,
    this.lastSeen,
    this.frStatus,
    this.reqId,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      username: json['username']?.toString() ?? '',
      email: json['email']?.toString() ?? '',
      role: json['role']?.toString() ?? 'user',
      isOnline: json['is_online'] == true || json['is_online'] == 1,
      lastSeen: json['last_seen']?.toString(),
      frStatus: json['fr_status']?.toString(),
      reqId: json['req_id']?.toString(),
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'username': username,
    'email': email,
    'role': role,
    'is_online': isOnline,
    'last_seen': lastSeen,
  };
}

class DmThreadModel {
  final String id;
  final String peerId;
  final String peerName;
  final String peerUsername;
  final String peerEmail;
  final bool isOnline;
  final String? peerLastSeen;
  final int unread;
  final String? lastBody;
  final String? lastImage;
  final String updatedAt;

  DmThreadModel({
    required this.id,
    required this.peerId,
    required this.peerName,
    required this.peerUsername,
    required this.peerEmail,
    required this.isOnline,
    this.peerLastSeen,
    required this.unread,
    this.lastBody,
    this.lastImage,
    required this.updatedAt,
  });

  factory DmThreadModel.fromJson(Map<String, dynamic> json) {
    return DmThreadModel(
      id: json['id']?.toString() ?? '',
      peerId: json['peer_id']?.toString() ?? '',
      peerName: json['peer_name']?.toString() ?? 'User',
      peerUsername: json['peer_username']?.toString() ?? '',
      peerEmail: json['peer_email']?.toString() ?? '',
      isOnline: json['is_online'] == true || json['is_online'] == 1,
      peerLastSeen: json['peer_last_seen']?.toString(),
      unread: int.tryParse(json['unread']?.toString() ?? '0') ?? 0,
      lastBody: json['last_body']?.toString(),
      lastImage: json['last_image']?.toString(),
      updatedAt: json['updated_at']?.toString() ?? '',
    );
  }
}

class MessageModel {
  final String id;
  final String? senderId;
  final String? role;
  final String body;
  final String? imageUrl;
  final String createdAt;
  final bool isMe;

  MessageModel({
    required this.id,
    this.senderId,
    this.role,
    required this.body,
    this.imageUrl,
    required this.createdAt,
    required this.isMe,
  });

  factory MessageModel.fromJson(Map<String, dynamic> json, String currentUserId) {
    final sender = json['sender_id']?.toString();
    final roleVal = json['role']?.toString() ?? json['sender_role']?.toString();
    final bool me = (sender != null && sender == currentUserId) || (roleVal == 'user' && currentUserId.isNotEmpty);
    return MessageModel(
      id: json['id']?.toString() ?? '',
      senderId: sender,
      role: roleVal,
      body: json['body']?.toString() ?? '',
      imageUrl: json['image_url']?.toString(),
      createdAt: json['created_at']?.toString() ?? '',
      isMe: me,
    );
  }
}

class FriendModel {
  final String friendId;
  final String friendName;
  final String friendUsername;
  final String friendEmail;
  final bool isOnline;
  final String? lastSeen;
  final String? threadId;

  FriendModel({
    required this.friendId,
    required this.friendName,
    required this.friendUsername,
    required this.friendEmail,
    required this.isOnline,
    this.lastSeen,
    this.threadId,
  });

  factory FriendModel.fromJson(Map<String, dynamic> json) {
    return FriendModel(
      friendId: json['friend_id']?.toString() ?? '',
      friendName: json['friend_name']?.toString() ?? '',
      friendUsername: json['friend_username']?.toString() ?? '',
      friendEmail: json['friend_email']?.toString() ?? '',
      isOnline: json['is_online'] == true || json['is_online'] == 1,
      lastSeen: json['last_seen']?.toString(),
      threadId: json['thread_id']?.toString(),
    );
  }
}

class FriendRequestModel {
  final String id;
  final String fromUserId;
  final String fromName;
  final String fromEmail;
  final String createdAt;

  FriendRequestModel({
    required this.id,
    required this.fromUserId,
    required this.fromName,
    required this.fromEmail,
    required this.createdAt,
  });

  factory FriendRequestModel.fromJson(Map<String, dynamic> json) {
    return FriendRequestModel(
      id: json['id']?.toString() ?? '',
      fromUserId: json['from_user_id']?.toString() ?? '',
      fromName: json['from_name']?.toString() ?? 'User',
      fromEmail: json['from_email']?.toString() ?? '',
      createdAt: json['created_at']?.toString() ?? '',
    );
  }
}

class IncomingCallModel {
  final String callId;
  final String callerId;
  final String callerName;
  final String callerUsername;
  final String callType; // 'audio' or 'video'
  final String? threadId;

  IncomingCallModel({
    required this.callId,
    required this.callerId,
    required this.callerName,
    required this.callerUsername,
    required this.callType,
    this.threadId,
  });

  factory IncomingCallModel.fromJson(Map<String, dynamic> json) {
    return IncomingCallModel(
      callId: json['call_id']?.toString() ?? '',
      callerId: json['caller_id']?.toString() ?? '',
      callerName: json['caller_name']?.toString() ?? 'Caller',
      callerUsername: json['caller_username']?.toString() ?? '',
      callType: json['call_type']?.toString() ?? 'audio',
      threadId: json['thread_id']?.toString(),
    );
  }
}
