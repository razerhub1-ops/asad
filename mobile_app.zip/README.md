# Flutter Chat & Calling Mobile Application (Android & iOS)

Yeh project aapke PHP + MySQL chat backend ke liye **100% Native Flutter Mobile Application** hai.

---

## 🌟 App Features (Khasusiyaat)

1. **Authentication (Login & Signup):**
   - Username/Email aur Password se Login aur Signup.
   - Secure Bearer Token Authentication (PHP session ya cookie crash ka koi dar nahi).
   - Auto-login (User credentials phone mein securely save rehte hain).

2. **Direct Messaging (DMs):**
   - WhatsApp-style ultra-smooth chat layout.
   - Real-time message synchronization with timestamps aur double ticks.
   - Camera & Gallery se instant photo sharing/uploading.

3. **Audio & Video Calling (WebRTC):**
   - Voice Call & Video Call support.
   - Incoming call ringtone & alert popup dialog.
   - In-call controls: Mute microphone, Switch camera (front/back), Hang up button.

4. **Friends & Community:**
   - Live user search (Username ya Name ke zariye).
   - Send friend request, incoming request notifications, Accept / Reject buttons.
   - Online status indicator (Green dot jab user online ho).

5. **Customer Support Chat:**
   - Dedicated Help Desk tab jahan user direct Admin se rabta kar sakta hai.

6. **Dynamic Server Configuration:**
   - App ke andar Settings button se kisi bhi waqt aap apna live domain URL badal sakte hain (jaise `https://yourdomain.com/chat`).

---

## 📁 Project Structure

```
mobile_app/
├── lib/
│   ├── config/
│   │   └── api_config.dart        # Server URL aur API route endpoints
│   ├── models/
│   │   └── models.dart            # User, Message, Thread, Call data models
│   ├── services/
│   │   └── api_service.dart       # HTTP Requests, Token Auth, WebRTC Signaling
│   ├── screens/
│   │   ├── login_screen.dart      # Login UI & Server URL Setup
│   │   ├── register_screen.dart   # Sign up UI
│   │   ├── home_screen.dart       # Conversations, Friends, Support & Settings Tabs
│   │   ├── chat_screen.dart       # Real-time chat & image sending
│   │   ├── call_screen.dart       # Audio/Video calling (WebRTC)
│   │   ├── user_search_screen.dart# Search & Add Friends
│   │   └── support_screen.dart    # Customer Support UI
│   └── main.dart                  # App starting point & Modern Dark Theme
├── android/
│   └── app/src/main/AndroidManifest.xml  # Android Camera, Mic, Internet permissions
├── ios/
│   └── Runner/Info.plist          # iOS Camera, Mic permissions
└── pubspec.yaml                   # Flutter dependencies
```

---

## 🚀 How to Run & Build (Chalane Ka Tareeqa)

### Step 1: Flutter Install Karein
Agar aapke computer par Flutter install nahi hai:
1. [flutter.dev](https://flutter.dev) se Flutter SDK download karein.
2. Flutter ko PATH mein add karein.
3. Terminal ya Command Prompt mein check karein:
   ```bash
   flutter doctor
   ```

### Step 2: Dependencies Install Karein
`mobile_app` folder mein terminal kholein aur run karein:
```bash
cd mobile_app
flutter pub get
```

### Step 3: Server Domain Set Karein
`lib/config/api_config.dart` file kholein aur `_defaultBaseUrl` mein apna live hosting URL daalein:
```dart
static const String _defaultBaseUrl = 'https://YOURDOMAIN.COM/chat';
```
*(Ya app chalne ke baad Login screen par Settings ⚙️ icon daba kar bhi URL save kar sakte hain).*

### Step 4: App Run Karein
Phone ko USB se connect karein (USB Debugging ON karein) ya Emulator chalayein, phir run karein:
```bash
flutter run
```

---

## 📦 Android Release APK Kaise Banayein (Play Store / Direct Install)

Direct apne Android phone par install karne ke liye APK file banane ka tareeqa:

```bash
flutter build apk --release
```

Build hone ke baad APK file yahan milegi:
`build/app/outputs/flutter-apk/app-release.apk`

Isko direct kisi bhi Android phone par send kar ke install kar sakte hain!

---

## 🍏 iOS Build (App Store / TestFlight)

Mac computer par Xcode ke zariye:
```bash
flutter build ipa
```
Phir Xcode Organizer se App Store ya TestFlight par upload karein.
